<?php
    ob_start();
     session_start();
    
    if(!isset($_SESSION['rol']) || $_SESSION['rol'] != 2){
    header('location: ../../login.php');

}
$id=$_SESSION['id'];
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="../../../backend/css/admin.css">
    <link rel="icon" type="image/png" sizes="96x96" href="../../img/cm2.png">

    <!-- Data Tables -->
    <link rel="stylesheet" type="text/css" href="../../../backend/css/datatable.css">
    <link rel="stylesheet" type="text/css" href="../../../backend/css/buttonsdataTables.css">
    <link rel="stylesheet" type="text/css" href="../../../backend/css/font.css">


    <title>La Cruz</title>
</head>
<body>
    
    <!-- SIDEBAR -->
    <section id="sidebar">
        <a href="../escritorio.php" class="brand"><img src="../../img/cm1.png" alt="" style="width:220px; height:180px;"> </a>
        <ul class="side-menu">
            <li><a href="../escritorio.php" ><i class='bx bxs-dashboard icon' ></i>Inicio</a></li>
            <li class="divider" data-text="Menú">Menú</li>
            <li>
                <a href="#" class="active"><i class='bx bxs-book-alt icon' ></i> Citas <i class='bx bx-chevron-right icon-right' ></i></a>
                <ul class="side-dropdown">
                    <li><a href="mostrar.php">Lista de citas</a></li>
                    <li><a href="nuevo.php">Nueva</a></li>
                    <li><a href="calendario.php">Calendario</a></li>
                   
                </ul>
            </li>

            <li>
                <a href="#"><i class='bx bxs-user icon' ></i> Pacientes <i class='bx bx-chevron-right icon-right' ></i></a>
                <ul class="side-dropdown">
                    <li><a href="../pacientes/mostrar.php" >Lista de pacientes</a></li>
                    <li><a href="../pacientes/nuevo.php">Nuevo paciente</a></li>
                   
                </ul>
            </li>

            <li>
                <a href="#"><i class='bx bxs-cog icon' ></i> Ajustes<i class='bx bx-chevron-right icon-right' ></i></a>
                <ul class="side-dropdown">
                    <li><a href="../ajustes/mostrar.php">Ajustes</a></li>
                </ul>
            </li>
           
        </ul>
       

    </section>
    <!-- SIDEBAR -->

    <!-- NAVBAR -->
    <section id="content">
        <!-- NAVBAR -->
        <nav>
            <i class='bx bx-menu toggle-sidebar'></i>
            <form action="#">
                <div class="form-group">
                </div>
            </form>
            
           
            <span class="divider"></span>
            <div class="profile">
            <img src="../../img/cm4.png" alt="">
                <ul class="profile-link">
                   <li><a href="../profile/mostrar.php?id=<?php echo $id ?>"><i class='bx bxs-user-circle icon' ></i>Mi Perfil</a></li>
                    
                    <li>
                     <a href="../../salir.php"><i class='bx bxs-log-out-circle' ></i>Cerrar Sesión</a>
                    </li>
                   
                </ul>
            </div>
        </nav>
        <!-- NAVBAR -->

        <!-- MAIN -->
        <main>
         
            <button class="button" onclick="location.href='nuevo.php'">Nuevo</button>
          <div class="data">
                <div class="content-data">
                    <div class="head">
                        <h3>Citas</h3>
                      

                    </div>
                   <div class="table-responsive" style="overflow-x:auto;">
                       <?php 
require '../../../backend/bd/Conexion.php';
$sentencia = $connect->prepare("SELECT events.id, events.title, patients.idpa, patients.numhs,patients.nompa, patients.apepa, doctor.idodc, doctor.ceddoc, doctor.nodoc, doctor.apdoc, laboratory.idlab, laboratory.nomlab, events.start, events.end, events.color, events.state,events.monto FROM events INNER JOIN patients ON events.idpa = patients.idpa INNER JOIN doctor ON events.idodc = doctor.idodc INNER JOIN laboratory ON events.idlab = laboratory.idlab ORDER BY id DESC;");
 $sentencia->execute();
$data =  array();
if($sentencia){
  while($r = $sentencia->fetchObject()){
    $data[] = $r;
  }
}
     ?>
     <?php if(count($data)>0):?>
         <table id="example" class="responsive-table">
            <thead>
                <tr>
                    <th scope="col">Pacientes</th>
                    <th scope="col">Motivo</th>
                    <th scope="col">Médico</th>
                    <th scope="col">Especialidad</th>
                    <th scope="col">Fecha inicio</th>
                    <th scope="col">Estado</th>
                    <th scope="col">Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($data as $d):?>
                    <tr>
                        <th scope="row"><?php echo $d->nompa ?>&nbsp;<?php echo $d->apepa ?></th>
                        <td data-title="Cita"><?php echo $d->title ?></td>
                        <td data-title="Médico"><?php echo $d->nodoc ?>&nbsp;<?php echo $d->apdoc ?></td>
                        <td data-title="Laboratorio"><?php echo $d->nomlab ?></td>
                        <td data-title="Fecha inicio"><?php echo $d->start ?></td>
                        <td data-title="Estado">
    
    <label class="switch">
<input type="checkbox" id="<?=$d->id?>" value="<?=$d->state ?>" <?=$d->state == '1' ? 'checked' : '' ;?> onchange="updateState(this, <?=$d->id?>)"/>
<span class="slider"></span>
</label>

<script>
function updateState(element, id) {
var state = element.checked ? 1 : 0; // Si el checkbox está marcado, el estado será 1, de lo contrario será 0


if(state===1){
alert("No se puede habilitar una cita cancelada")
element.checked = false;
return;
}

if (state === 0) {
// Mostrar una alerta de confirmación antes de cambiar el estado a 0
if (confirm("¿Estás seguro de que deseas cancelar la cita?")) {
// Enviar una solicitud AJAX a tu archivo PHP para actualizar el valor de "state" en la base de datos
var xhr = new XMLHttpRequest();
xhr.open('GET', 'actualizar_estado.php?id=' + id + '&state=' + state, true);
xhr.onreadystatechange = function() {
if (xhr.readyState === 4 && xhr.status === 200) {
    // Hacer algo con la respuesta del servidor, si es necesario
    if (xhr.responseText === 'success') {
        element.checked = false; // Desmarcar el checkbox una vez que se haya cancelado la cita
        element.disabled = true; // Deshabilitar el checkbox para evitar que se vuelva a activar
    }
}
};
xhr.send();
} else {
// Si el usuario cancela la confirmación, volver a marcar el checkbox
element.checked = true;
}
} else {
// Enviar una solicitud AJAX a tu archivo PHP para actualizar el valor de "state" en la base de datos
var xhr = new XMLHttpRequest();
xhr.open('GET', 'actualizar_estado.php?id=' + id + '&state=' + state, true);
xhr.onreadystatechange = function() {
if (xhr.readyState === 4 && xhr.status === 200) {
// Hacer algo con la respuesta del servidor, si es necesario
}
};
xhr.send();
}




}
</script> 
                       
                        
                   
                        <td>        

                            <a title="Información" href="../citas/info.php?id=<?php echo $d->id ?>" class="fa fa-info"></a>
                            <input type='hidden' name='idcita' value="<?php echo  $d->idcita; ?>">
                            
                            <?php 
                                echo '<a title="Boleta"  href="../../citas/documento.php?id='.$d->id.'" class="fa fa-file-text-o"></a>';                      
                            ?>

                            <br>


                        </td>
                    </tr>

                    <?php endforeach; ?>
            </tbody>
         </table> 
         <?php else:?>
  
    <div class="alert">
      <span class="closebtn" onclick="this.parentElement.style.display='none';">&times;</span> 
      No hay citas agendadas.
    </div>
    <?php endif; ?>
                    </div>
                </div>
            </div>  

        </main>
        <!-- MAIN -->
    </section>
    
    <!-- NAVBAR -->
    <script src="../../../backend/js/jquery.min.js"></script>
    
    <script src="../../../backend/js/script.js"></script>
    
    <!-- Data Tables -->
    <script type="text/javascript" src="../../../backend/js/datatable.js"></script>
    <script type="text/javascript" src="../../../backend/js/datatablebuttons.js"></script>
    <script type="text/javascript" src="../../../backend/js/jszip.js"></script>
    <script type="text/javascript" src="../../../backend/js/pdfmake.js"></script>
    <script type="text/javascript" src="../../../backend/js/vfs_fonts.js"></script>
    <script type="text/javascript" src="../../../backend/js/buttonshtml5.js"></script>
    <script type="text/javascript" src="../../../backend/js/buttonsprint.js"></script>
    <script type="text/javascript">
$(document).ready(function() {
    $('#example').DataTable( {
        dom: 'Bfrtip',
        buttons: [
             'pdf', 'print'
        ]
    } );
} );
    </script>


    <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js"></script>
 
</body>
</html>


